<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] === "POST") 
    // Connect to the database (modify these parameters if needed)
    $host = "http://localhost:8080/";
    $username = "root";
    $password = "";
    $database = "bursary_application";

    // Create a connection
    $conn = new mysqli($host, $username, $password, $database);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get form data
    $applicant_name = $_POST["applicant_name"];
    $county = $_POST["county"];
    $scanned_form_filename = $_FILES["scanned_form"]["name"];

    // Prepare and execute the SQL query to insert the data into the table
    $sql = "INSERT INTO applications (applicant_name, county, scanned_form_filename) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $applicant_name, $county, $scanned_form_filename);

    if ($stmt->execute()) {
        // File upload handling (move the uploaded file to a folder on the server)
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($_FILES["scanned_form"]["name"]);
        move_uploaded_file($_FILES["scanned_form"]["tmp_name"], $target_file);

        echo "Application submitted successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close the connection
    $stmt->close();
    $conn->close();

?>
